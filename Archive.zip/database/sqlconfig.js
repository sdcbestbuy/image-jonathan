module.exports = {
  host:'localhost',
  user: 'root',
  password: 'Bruins2011!',
  database: 'bestbuy'
};
