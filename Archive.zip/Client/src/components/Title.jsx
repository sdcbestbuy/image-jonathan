import React from 'react';
const Title = ({title}) =>(
<div id="title">
{title}
</div>
)

export default Title;