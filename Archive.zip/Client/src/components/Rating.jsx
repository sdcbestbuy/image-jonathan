import React from 'react';
let Rating = ({rating}) => (
<div id="rating">
<div id="total-reviews">
<img id="stars" src="https://i.ibb.co/F3zgWkv/stars.jpg" />4.6 (54 reviews)</div>
</div>
)
export default Rating;