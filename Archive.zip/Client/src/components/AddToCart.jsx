import React from 'react';

const AddToCart = ()=> (
  <button type="button" id="add-to-cart">
    <img id="cart" src="https://i.ibb.co/MkrbHwc/cart.jpg" />
     Add to Cart
  </button>
)
export default AddToCart;