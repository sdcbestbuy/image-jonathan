import React from 'react';

const Category = ({category})=> (
  <div id='category'>
  <ul>
    <li>Circuit City</li>
    <li> <img id='arrow' src='https://i.ibb.co/3mQM4yj/arrow.jpg'/> Electronics</li>
    </ul>
</div>
)

export default Category;