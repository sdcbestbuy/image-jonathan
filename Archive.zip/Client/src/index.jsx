import App from './app.jsx';
import ReactDOM from 'react-dom';
import React from 'react'

ReactDOM.render(<App />, document.getElementById('app'));